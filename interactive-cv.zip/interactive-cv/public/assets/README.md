# Assets

This folder is empty on purpose — the game currently runs on placeholder
graphics (grid floor, coloured rectangles) so it's playable with zero
external assets.

You'll need **two** Kenney downloads for the full look — environment tiles
and characters are separate packs:

- **Environment**: Kenney "Roguelike/RPG Pack" — https://kenney.nl/assets/roguelike-rpg-pack
  (1,700 tiles: floors, walls, furniture, props — no characters)
- **Characters**: Kenney "Roguelike Characters" — https://kenney.nl/assets/roguelike-characters
  (450 assets: modular characters — base + clothing/armor/headgear/hair/weapons,
  plus a few pre-made sample characters on the sheet)

Both are CC0 and share the same art style/grid size, so they look right
together.

## 1. Environment tiles + map

1. Drop the environment spritesheet in as `public/assets/tileset.png`.
2. Check the `tilemap.txt` included in the download for the exact tile
   width/height/margin/spacing — Kenney sheets often have a 1px gap
   between tiles, so don't assume 0/0.
3. Build a map in [Tiled](https://www.mapeditor.org/) using that tileset,
   export as JSON to `public/assets/map.json`. Name your layers `Ground`
   and `Walls` (or update the layer names in `WorldScene.js` to match
   whatever you used). Tag wall tiles with a boolean custom property
   `collides = true`.
4. In `src/scenes/WorldScene.js`, set `USE_TILEMAP = true`, update the
   `frameWidth`/`frameHeight`/`margin`/`spacing` values in `preload()` to
   match step 2, and set `TILESET_NAME_IN_TILED` to whatever you named the
   tileset inside Tiled.

## 2. Character sprites

1. Drop the characters spritesheet in as `public/assets/characters.png`.
2. Again, check that pack's own `tilemap.txt` — its grid may differ from
   the environment tileset's.
3. In `src/scenes/WorldScene.js`, set `USE_CHARACTER_SPRITES = true` and
   update the `frameWidth`/`frameHeight`/`margin`/`spacing` values for the
   characters spritesheet in `preload()`.
4. Pick a frame index for the player: open the sheet in an image viewer
   and count grid cells left-to-right, top-to-bottom starting at 0 (or use
   Tiled's tileset viewer, which numbers them for you). Set `PLAYER_FRAME`
   to that number.
5. Each NPC can specify its own sprite frame via frontmatter in its
   markdown file:
   ```yaml
   ---
   npc: "The Toolsmith"
   sprite: 12
   ---
   ```
   NPCs without a `sprite` field fall back to `DEFAULT_NPC_FRAME`.

Note: the Roguelike Characters pack is *modular* — the sheet has separate
base bodies, clothing, hair, etc. meant to be layered. This scaffold only
wires up a single static frame per character (simplest starting point). If
you want to layer pieces or add walk-cycle animation later, that's a
`this.anims.create(...)` + multiple sprite layers job — happy to help wire
that up once the single-frame version is running.
