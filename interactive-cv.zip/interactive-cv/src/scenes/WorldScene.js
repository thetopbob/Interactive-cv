import Phaser from 'phaser';
import content from '../data/content.generated.json';
import DialogBox from '../ui/DialogBox.js';

const INTERACT_RANGE = 56;
const PLAYER_SPEED = 180;

export default class WorldScene extends Phaser.Scene {
  constructor() {
    super('WorldScene');
  }

  create() {
    this.dialog = new DialogBox();

    this.drawGroundPlaceholder();

    // NOTE: This grid + rectangle-sprite setup is a placeholder "overworld"
    // so the game is playable with zero external assets. Once you drop a
    // Tiled map + Kenney tileset into public/assets, swap this method (and
    // the player/NPC creation below) for this.make.tilemap(...) calls.
    // See public/assets/README.md for the swap-in steps.

    this.npcs = content.map((entry) => this.createNpc(entry));

    this.player = this.createPlayer();

    this.physics.add.collider(
      this.player,
      this.npcs.map((n) => n.sprite)
    );

    this.interactLabel = this.add
      .text(0, 0, 'Press E', {
        fontFamily: 'monospace',
        fontSize: '13px',
        color: '#14121f',
        backgroundColor: '#c9a35c',
        padding: { x: 6, y: 3 }
      })
      .setOrigin(0.5, 1)
      .setVisible(false)
      .setDepth(10);

    this.cursors = this.input.keyboard.createCursorKeys();
    this.wasd = this.input.keyboard.addKeys('W,A,S,D,E');

    this.activeNpc = null;
  }

  drawGroundPlaceholder() {
    // Simple two-tone grid standing in for a tilemap floor.
    const tile = 32;
    const g = this.add.graphics();
    for (let y = 0; y < 600; y += tile) {
      for (let x = 0; x < 800; x += tile) {
        const shade = (x / tile + y / tile) % 2 === 0 ? 0x24331f : 0x1e2a1e;
        g.fillStyle(shade, 1);
        g.fillRect(x, y, tile, tile);
      }
    }
  }

  createNpc(entry) {
    const sprite = this.add.rectangle(entry.x, entry.y, 28, 28, 0xc9a35c);
    sprite.setStrokeStyle(2, 0x14121f);
    this.physics.add.existing(sprite, true); // static body

    this.add
      .text(entry.x, entry.y - 26, entry.npc, {
        fontFamily: 'monospace',
        fontSize: '12px',
        color: '#f3e6d0'
      })
      .setOrigin(0.5);

    return { ...entry, sprite };
  }

  createPlayer() {
    const player = this.add.rectangle(400, 460, 24, 24, 0x57d1c9);
    player.setStrokeStyle(2, 0x14121f);
    this.physics.add.existing(player);
    player.body.setCollideWorldBounds(true);
    player.body.setSize(24, 24);
    return player;
  }

  update() {
    if (this.dialog.isOpen()) {
      this.player.body.setVelocity(0);
      return;
    }

    this.handleMovement();
    this.handleInteraction();
  }

  handleMovement() {
    const body = this.player.body;
    let vx = 0;
    let vy = 0;

    if (this.cursors.left.isDown || this.wasd.A.isDown) vx = -PLAYER_SPEED;
    else if (this.cursors.right.isDown || this.wasd.D.isDown) vx = PLAYER_SPEED;

    if (this.cursors.up.isDown || this.wasd.W.isDown) vy = -PLAYER_SPEED;
    else if (this.cursors.down.isDown || this.wasd.S.isDown) vy = PLAYER_SPEED;

    // Normalize diagonal movement so it isn't faster than cardinal movement.
    if (vx !== 0 && vy !== 0) {
      vx *= Math.SQRT1_2;
      vy *= Math.SQRT1_2;
    }

    body.setVelocity(vx, vy);
  }

  handleInteraction() {
    let nearest = null;
    let nearestDist = INTERACT_RANGE;

    for (const npc of this.npcs) {
      const dist = Phaser.Math.Distance.Between(
        this.player.x,
        this.player.y,
        npc.x,
        npc.y
      );
      if (dist < nearestDist) {
        nearest = npc;
        nearestDist = dist;
      }
    }

    this.activeNpc = nearest;

    if (nearest) {
      this.interactLabel
        .setPosition(nearest.x, nearest.y - 34)
        .setVisible(true);
    } else {
      this.interactLabel.setVisible(false);
    }

    if (Phaser.Input.Keyboard.JustDown(this.wasd.E) && this.activeNpc) {
      this.dialog.open(this.activeNpc.npc, this.activeNpc.title, this.activeNpc.html);
    }
  }
}
