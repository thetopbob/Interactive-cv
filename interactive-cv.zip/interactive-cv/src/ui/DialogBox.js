export default class DialogBox {
  constructor() {
    this.overlay = document.getElementById('dialog-overlay');
    this.npcEl = document.getElementById('dialog-npc');
    this.titleEl = document.getElementById('dialog-title');
    this.bodyEl = document.getElementById('dialog-body');
    this.closeBtn = document.getElementById('dialog-close');

    this._open = false;

    this.closeBtn.addEventListener('click', () => this.close());
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this._open) this.close();
    });
  }

  open(npcName, title, html) {
    this.npcEl.textContent = npcName;
    this.titleEl.textContent = title;
    this.bodyEl.innerHTML = html;
    this.overlay.classList.remove('hidden');
    this._open = true;
  }

  close() {
    this.overlay.classList.add('hidden');
    this._open = false;
  }

  isOpen() {
    return this._open;
  }
}
