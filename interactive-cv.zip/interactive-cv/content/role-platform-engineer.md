---
npc: "The Platform Sage"
title: "Principal Platform Engineer"
x: 240
y: 180
order: 1
---

Keeper of the release pipelines and guardian of the ~10,000-seat Salesforce org.

- Owns CI/CD, observability strategy, and cloud infrastructure on AWS
- Specialises in DevOps, release engineering, and AI tooling integration
- Currently investigating AWS WAF managed rule changes affecting `Authorization` headers

Ask about the agent pipeline or the launch monitor to hear more tales.
