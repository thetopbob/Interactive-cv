---
npc: "The Toolsmith"
title: "Skills & Tools"
x: 620
y: 440
order: 4
---

- **Platform & Cloud**: AWS, Terraform, ECS, observability (OpenTelemetry, Datadog, Grafana)
- **CI/CD**: GitLab CI, GitHub Actions, release engineering
- **AI/Agentic**: LangGraph, LangChain, RAG pipelines (LanceDB, Qdrant), provider-agnostic LLM tooling
- **Salesforce**: large-org administration, Apex, security hardening, CPQ configuration
- **Languages**: Go, Python, JavaScript/TypeScript, Apex
